<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>Курский вокзал</title>
        <link rel="icon" href="resources/favicon.ico" type="image/x-icon">
        <link rel="stylesheet" type="text/css" href="styles/nav.css">
        <link rel="stylesheet" type="text/css" href="styles/texts.css">
        <link rel="stylesheet" type="text/css" href="styles/frgments.css">

    </head>
    <body>
        <?php
            include_once("helphp/nav.php");
        ?>

        <article1>
                <h3>Добро пожаловать на сайт с расписанием </br></h3><h1>Курского Вокзала</h1>
        </article1>

            <div style="float: right; margin-right: 70px">
                <a class="twitter-timeline" data-lang="ru" data-width="220" data-height="600" data-theme="dark" href="https://twitter.com/rzd_official?ref_src=twsrc%5Etfw">Tweets by rzd_official</a>
                <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>
            </div>

            <div style="float: right; margin-right: 250px">
                <img src="resources/main.jpg" class="main_image" >
            </div>

    </body>
</html>